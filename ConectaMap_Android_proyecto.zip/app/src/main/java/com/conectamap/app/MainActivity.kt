package com.conectamap.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val navy = Color.rgb(24, 45, 83)
    private val teal = Color.rgb(24, 151, 151)
    private val pale = Color.rgb(240, 248, 250)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 28)
            setBackgroundColor(pale)
        }
        val scroll = ScrollView(this)
        scroll.addView(page)

        val logo = TextView(this).apply {
            text = "⌖"
            textSize = 46f
            setTextColor(teal)
            gravity = Gravity.CENTER
        }
        page.addView(logo, matchWrap())
        page.addView(text("ConectaMap", 30f, navy, true, Gravity.CENTER), matchWrap())
        page.addView(text("Conecta con tus amistades,\ncon seguridad y a tu ritmo.", 17f, Color.DKGRAY, false, Gravity.CENTER).apply {
            setPadding(0, 8, 0, 22)
        }, matchWrap())

        page.addView(section("Tus conexiones"))
        page.addView(infoCard("👥  Buscar amistades", "Esta pantalla de prueba todavía no busca cuentas reales."))
        page.addView(actionButton("Buscar personas") { toast("La búsqueda real se conectará en la siguiente etapa.") })
        page.addView(infoCard("✉️  Solicitudes de amistad", "En la versión conectada podrás aceptar o rechazar solicitudes."))
        page.addView(actionButton("Ver solicitudes") { toast("Las solicitudes reales aún no están conectadas.") })

        page.addView(section("Compartir ubicación"))
        page.addView(infoCard("📍  Tú decides", "La ubicación estará apagada por defecto. Solo se compartirá con amistades aceptadas y con tu permiso."))
        page.addView(actionButton("Configurar ubicación", false) { toast("No se solicita ni comparte ubicación en esta versión de prueba.") })

        val notice = TextView(this).apply {
            text = "PROTOTIPO INSTALABLE · Sin cuentas, servidor ni GPS real todavía. No uses esta versión para compartir tu ubicación real."
            textSize = 13f
            setTextColor(navy)
            setPadding(14, 16, 14, 16)
            setBackgroundColor(Color.rgb(220, 235, 241))
        }
        val params = matchWrap().apply { topMargin = 20 }
        page.addView(notice, params)
        setContentView(scroll)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun text(value: String, size: Float, color: Int, bold: Boolean, gravityValue: Int = Gravity.START) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        gravity = gravityValue
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun section(value: String): TextView = text(value, 19f, navy, true).apply {
        setPadding(0, 22, 0, 10)
    }

    private fun infoCard(title: String, detail: String): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(Color.WHITE)
        }
        card.addView(text(title, 17f, navy, true), matchWrap())
        card.addView(text(detail, 14f, Color.DKGRAY, false).apply { setPadding(0, 6, 0, 0) }, matchWrap())
        val p = matchWrap().apply { bottomMargin = 8 }
        card.layoutParams = p
        return card
    }

    private fun actionButton(label: String, enabled: Boolean = true, action: () -> Unit): Button = Button(this).apply {
        text = label
        isEnabled = enabled
        setTextColor(if (enabled) Color.WHITE else Color.DKGRAY)
        if (enabled) backgroundTintList = android.content.res.ColorStateList.valueOf(teal)
        setOnClickListener { action() }
        val p = matchWrap().apply { bottomMargin = 8 }
        layoutParams = p
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
